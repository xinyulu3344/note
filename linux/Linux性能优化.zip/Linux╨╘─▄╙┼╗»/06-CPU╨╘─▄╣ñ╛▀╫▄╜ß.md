# CPU性能工具总结

## 从CPU 的性能指标维度

![img](images/596397e1d6335d2990f70427ad4b14ec.png)

## 从工具维度

![img](images/b0c67a7196f5ca4cc58f14f959a364ca.png)

